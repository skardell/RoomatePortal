module HouseholdHelper
end
