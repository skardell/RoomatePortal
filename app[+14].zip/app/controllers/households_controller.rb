class HouseholdController < ApplicationController
    
    def users_params
    params.require(:users).permit(:username, :email, :session_token, :household)
    end
  
  
  def new
    
  end
  
  def create
    
    if User.find_by(username: users_params[:username]) == nil
        if User.find_by(household: users_params[:household]) == nil
            @users = User.create_user!(users_params)
            flash[:notice] = "Hello #{@users.username}, your account was successfully created."
            redirect_to login_path
        else
            flash[:notice] = "Sorry, this Household ID is taken. Try again."
            redirect_to new_user_path
        end
    else
      flash[:notice] = "Sorry, this user-id is taken. Try again."
      redirect_to new_user_path
    end
  end
end
