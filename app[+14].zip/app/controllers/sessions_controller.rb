class SessionsController < ApplicationController
  
  def session_params
    params.require(:user).permit(:username, :email, :session_token)
  end
  
  def new
  end

  def create
    if User.find_by(username: session_params[:username]) != nil
      user = User.find_by_username(session_params[:username])
      if (user.email == session_params[:email])
        session[:session_token] = user.session_token
        
        flash[:notice] = "Hello #{user.username}, you are now logged in."
        
        
        
        redirect_to movies_path
      else
        flash[:notice] = "Invalid username/email. Try again."
        redirect_to login_path
      end
    else
      flash[:notice] = "Invalid username/email. Try again."
      redirect_to login_path
    end
    
    
  end

  def destroy
    
    reset_session
    redirect_to movies_path
  end
end
