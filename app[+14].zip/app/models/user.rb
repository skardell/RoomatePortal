class User < ActiveRecord::Base
    
    class << self
      def create_user!(parameters)
        parameters[:session_token] =  SecureRandom.base64
      
        create!(parameters)
      
      end
      
    
    end
    
    
    #validates :username, :presence => true, :uniqueness => true
    #validates :email, :presence => true, :format => /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i
    
end
