require 'rails_helper'

RSpec.describe SessionsController, type: :controller do

end
