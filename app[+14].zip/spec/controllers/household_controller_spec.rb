require 'rails_helper'

RSpec.describe HouseholdController, type: :controller do

end
